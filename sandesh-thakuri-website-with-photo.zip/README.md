# Sandesh Thakuri — Personal Website

This is a zero-cost static personal website.

## Files
- `index.html` — the complete website (HTML + CSS + JavaScript)

## Publish for free with GitHub Pages
1. Create a free GitHub account at github.com.
2. Create a new public repository named `sandesh-thakuri.github.io` (replace with your GitHub username if desired).
3. Upload `index.html`.
4. In the repository, open **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
6. Your website will be available at `https://YOUR-USERNAME.github.io/`.

No paid hosting is required.
